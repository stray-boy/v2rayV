# v2rayN

### How to use
- If you are newbie please download v2rayN-Core.zip from releases
- Otherwise please download v2rayN.zip (Also need to download v2ray core in the same folder)
- Run v2rayN.exe

### Requirements  
- Microsoft [.NET Framework 4.6](https://docs.microsoft.com/zh-cn/dotnet/framework/install/guide-for-developers) or higher
- Project V core [https://github.com/v2fly/v2ray-core/releases](https://github.com/v2fly/v2ray-core/releases)
