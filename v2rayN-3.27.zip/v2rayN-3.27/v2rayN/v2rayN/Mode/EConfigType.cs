﻿
namespace v2rayN.Mode
{
    public enum EConfigType
    {
        Vmess = 1,
        Custom = 2,
        Shadowsocks = 3,
        Socks = 4,
        VLESS = 5,
        Trojan = 6
    }
}
